<?php 
	
	error_reporting(E_ALL ^ E_NOTICE);

	session_start();
	$e = $_SESSION['email'];
	$u = $_SESSION['username'];
	
 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/home.css">
	<script type="text/javascript" src="js/jquery.js"></script>
	
</head>
<body>
	<div class="container">
		<form class="row m-5" method="get" action="includes/search.php">
			<input type="text" name="key" class="form-control col-lg-10" placeholder="search by catagory..." autocomplete="off" required>
			<input type="submit" name="" class="btn btn-primary ml-3" value="search">
			<img src="images/menu_480px.png" width="36px" height="36px" class="ml-3" id="img1">
		</form>
		<div id="menu" class="rounded">
			<p><a href="profile1.php" class="text-muted">Visit Profile</a></p>

			<?php 

				if($e && $u){

					echo "<p><a href='report.php' class='text-muted'>Feedback</a></p>";
				}

			 ?>
			
			<p><a href="signin.php" class="text-muted">Signin</a></p>
			<p><a href="signup.php" class="text-muted">Signup</a></p>
			<p><a href="logout.php" class="text-muted">logout</a></p>
		</div>
		<div>
			<h1 class="text-center text-white">INFINITI</h1>
		</div>
		
			<?php 

				error_reporting(E_ALL ^ E_NOTICE);
				include("connection.php");


				$fetch = mysqli_query($connection,"SELECT * FROM post ORDER BY id DESC");

				while($row = mysqli_fetch_assoc($fetch)){
					$id = $row['id'];
					$title = $row['title'];
					$content = $row['content'];
					$img = $row['img'];
					$author = $row['author'];
					$tags = $row['tag'];
					$catagory = $row['catagory'];
					$date = $row['pdate'];

					echo "
						<div id='main' class='rounded p-5 mt-5'>
						<a href='viewpost.php?id=$id'>
						<table class='table table-borderless'>
							<tr>
								<th>
									<h3>$title</h3>
								</th>
								<th>
									
								</th>
								<th></th>
								<th></th>
								<th></th>
								<th></th>
								<th></th>
								<th>
									author:<em class='font-weight-lighter'>$author</em>|
									tags:<em class='font-weight-lighter'>$tags</em>|$date
								</th>
							</tr>
							<tr>
								<td>
									<img src='uploads/$img' width='100px' height='100px'>
								</td>
								<td class= colspan='6'>
									$content.<strong>catagory:$catagory</string>
								</td>
							</tr>
						</table></a>
						</div>
					";
				}

 			?>
		
	</div>
	<script type="text/javascript">
		$(document).ready(function(){
			$("#img1").click(function(){
				$("#menu").toggle("fast");
			});
		});
	</script>
</body>
</html>