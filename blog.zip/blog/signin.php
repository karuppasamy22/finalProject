<?php 

	error_reporting(E_ALL ^ E_NOTICE);
	include("connection.php");

	$email = $_POST['email'];
	$password = md5($_POST['password']);
	$error = [];

	
	if(isset($_POST['btn'])){

		if(!empty($email) && !empty($password)){
			$select = mysqli_query($connection,"SELECT * FROM signup WHERE email='$email' AND 
			password='$password'");

			$num_rows = mysqli_num_rows($select);

			if($num_rows == 1){

				while($f = mysqli_fetch_assoc($select)){

					$u = $f['username'];
					$e = $f['email'];
				}

				session_start();

				$_SESSION['email'] = $e;
				$_SESSION['username'] = $u;

				header("Location: index.php");

			}else{

				$error[] = "<p class='alert alert-danger text-center'>wrong email or password</p>";
			}
		}
	}

 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/signup.css">
</head>
<body>
	<form class="container col-lg-4 bg-light p-5 mt-5 rounded" method="post" action="">
		<h2 class="text-center border-bottom">Signin</h2>
		<div class="m-1">
			<div class="row" id="result">
				<?php 

					foreach($error as $e){
						echo $e;
					}
				 ?>
			</div>
			<div class="row">
				<label for="email">Email address</label>
				<input type="email" name="email" class="form-control" id="email" autocomplete="off" required>
			</div>
			<div class="row">
				<label for="password">Password</label>
				<input type="password" name="password" class="form-control" id="password" autocomplete="off" required>
			</div>
			<div class="row mt-3">
				<input type="submit" name="btn" class="btn btn-success" value="signin" id="submit_button">
			</div>
			<div class="row mt-3">
				<p class="text-center">Create an account?</p><a href="signup.php" class="">Signup</a>
			</div>
			
		</div>
	</form >
</body>
</html>