<?php 

	error_reporting(E_ALL ^ E_NOTICE);
	include('../connection.php');

	$username = $_POST['username'];
	$email = $_POST['email'];
	$password = md5($_POST['password']);

	if(!empty($username)&&!empty($email)&&!empty($password)){
		$select = mysqli_query($connection,"SELECT * FROM signup WHERE email='$email'");
		$num_row = mysqli_num_rows($select);

		if($num_row != 1){

			$query = "INSERT INTO signup(username,email,password) VALUES('$username','$email','$password')";

			$insert = mysqli_query($connection,$query);

			if($insert){

				echo " <p class='alert alert-success text-center'>successfully signup. Go to Signin</p>";



			}else{

				echo "<p class='alert alert-danger text-center'>failed to signup</p>";
			}
		}else{

			echo "<p class='alert alert-danger text-center'>Email already exist</p>";
		}
	}



	


 ?>