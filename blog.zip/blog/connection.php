<?php 


	$connection = mysqli_connect("localhost","root","");
	$database = mysqli_select_db($connection,"blog");

 ?>