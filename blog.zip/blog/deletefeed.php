<?php 


	error_reporting(E_ALL ^ E_NOTICE);
	include('connection.php');
	$get = $_GET['id'];

	$delete = mysqli_query($connection,"DELETE FROM feedback WHERE id='$get'");

	if($delete){

		header("location:manage.php");
	}

 ?>