<?php 

	session_start();

	$e = $_SESSION['email'];
	$u = $_SESSION['username'];

	session_destroy();
	header("location:index.php");

 ?>