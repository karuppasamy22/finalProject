<?php 

	
	error_reporting(E_ALL ^ E_NOTICE);
	include("connection.php");
	$error = [];
	$get = $_GET['id'];

	if(isset($_POST['btn'])){

		$title = $_POST['title'];
		$content = $_POST['content'];
		$tags = $_POST['tags'];
		$author = $_POST['author'];
		$catagory = $_POST['catagory'];

		$update1 = mysqli_query($connection,"UPDATE post SET title='$title' WHERE id='$get'");
		$update2 = mysqli_query($connection,"UPDATE post SET content='$content' WHERE id='$get'");
		$update4 = mysqli_query($connection,"UPDATE post SET tag='$tags' WHERE id='$get'");
		$update5 = mysqli_query($connection,"UPDATE post SET author='$author' WHERE id='$get'");
		$update6 = mysqli_query($connection,"UPDATE post SET catagory='$catagory' WHERE id='$get'");

		if($update1 && $update2 && $update4 && $update5 && $update6){

				$error[] = "<p class='alert alert-success'>post successfully</p>";
				header("location:manage.php");


		}else{

			$error[] = "<p class='alert alert-danger'>failed to post</p>";
		}
	}




 ?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/addpost.css">
</head>
<body>
	<form class="container col-lg-4 bg-light p-5 mt-5 rounded" method="post" action="" enctype="multipart/form-data">
		<h2 class="text-center border-bottom">Edit Post</h2>
		<div class="m-1">
			<div class="row" id="result">
				<?php 

					foreach ($error as $value) {
						echo $value;
					}

				 ?>
			</div>
			<div class="row">
				<?php 

					$fetch = mysqli_query($connection,"SELECT * FROM post WHERE id='$get'");
					while($row = mysqli_fetch_assoc($fetch)){

						$title = $row['title'];
						$content = $row['content'];
						$author= $row['author'];
						$tags = $row['tag'];

					}

				 ?>
				<label for="title">Title</label>
				<input type="text" name="title" class="form-control" id="title" autocomplete="off" value="<?php echo $title; ?>" required>
			</div>
			<div class="row">
				<label for="content">content</label>
				<textarea class="form-control" id="content" name="content" value="" required><?php echo $content; ?></textarea>
			</div>
			<div class="row">
				<label for="tags">tag</label>
				<input type="text" name="tags" class="form-control" id="tags" autocomplete="off" value="<?php echo $tags; ?>" required>
			</div>
			<div class="row">
				<label for="author">Author</label>
				<input type="text" name="author" class="form-control" id="author" autocomplete="off" value="<?php echo $author; ?>" required>
			</div>
			<div class="row">
				<label for="catagory">catagory</label>
				<select class="custom-select" id="catagory" name="catagory">
					<option name="catagory" value="functions">Functions</option>
					<option name="catagory" value="entertainment">Entertainment</option>
					<option name="catagory" value="education">Education</option>
					<option name="catagory" value="knowledge">Knowledge</option>
					<option name="catagory" value="travel">Travel</option>
					<option name="catagory" value="fun">Fun</option>
					<option name="catagory" value="other">Others</option>
				</select>
			</div>
			<div class="row mt-3">
				<input type="submit" name="btn" class="btn btn-success" value="Update" id="submit_button">
			</div>
		</div>
	</form>
</body>
</html>