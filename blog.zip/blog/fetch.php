<?php 

	error_reporting(E_ALL ^ E_NOTICE);
	include("connection.php");


	$fetch = mysqli_query($connection,"SELECT * FROM post ORDER BY id DESC");

	while($row = mysqli_fetch_assoc($fetch)){

		$title = $row['title'];
		$content = $row['content'];
		$img = $row['img'];
		$author = $row['author'];
		$tags = $row['tag'];
		$catagory = $row['catagory'];

		echo "

			<table class='table table-borderless'>
				<tr>
					<th>
						<h3>$title</h3>
					</th>
					<th>
						
					</th>
					<th></th>
					<th></th>
					<th></th>
					<th></th>
					<th></th>
					<th>
						author:$author|
						tags:$tags
					</th>
				</tr>
				<tr>
					<td>
						<img src='uploads/$img' width='100px' height='100px'>
					</td>
					<td class= colspan='6'>
						$content.<strong>catagory:$catagory</string>
					</td>
				</tr>
			</table>

		";
	}


 ?>