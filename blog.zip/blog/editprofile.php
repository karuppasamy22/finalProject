<?php 

	error_reporting(E_ALL ^ E_NOTICE);
	include('connection.php');
	$error = [];

	if(isset($_POST['btn'])){

		$bio = $_POST['bio'];
		$education = $_POST['education'];
		$work = $_POST['work'];
		$interest = $_POST['interest'];
		$contact = $_POST['contact'];

		$insert1 = mysqli_query($connection,"UPDATE profile SET bio='$bio' WHERE name='infiniti'");
		$insert2 = mysqli_query($connection,"UPDATE profile SET education='$education' WHERE name='infiniti'");
		$insert3 = mysqli_query($connection,"UPDATE profile SET work='$work' WHERE name='infiniti'");
		$insert4 = mysqli_query($connection,"UPDATE profile SET interest='$interest' WHERE name='infiniti'");
		$insert5 = mysqli_query($connection,"UPDATE profile SET contact='$contact' WHERE name='infiniti'");

		if($insert1 && $insert2 && $insert3 && $insert4 && $insert5){

			$error[] = "<p class='alert alert-success'>updated</p>";
			header("location:profile1.php");
		}else{

			$error[] = "<p class='alert alert-danger'>failed to update</p>";
		}
	}
	

 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/addpost.css">
</head>
<body>
	<form class="container col-lg-4 bg-light p-5 mt-5 rounded" method="post" action="">
		<h2 class="text-center border-bottom">Edit Profile</h2>
		<div class="m-1">
			<div class="row" id="result">
				<?php 

					foreach($error as $e){
						echo $e;
					}
				 ?>
			</div>
			<div class="row mt-3 mb-3">
				<a href="editpicture.php" class="text-primary">Edit Profile Picture</a>
			</div>
			<div class="row">
				<label for="email">Bio</label>
				<input type="text" name="bio" class="form-control" id="email" autocomplete="off" required>
			</div>
			<div class="row">
				<label for="password">Education</label>
				<input type="text" name="education" class="form-control" id="email" autocomplete="off" required>
			</div>
			<div class="row">
				<label for="password">Work</label>
				<input type="text" name="work" class="form-control" id="password" autocomplete="off" required>
			</div>
			<div class="row">
				<label for="password">Interest</label>
				<input type="text" name="interest" class="form-control" id="password" autocomplete="off"required>
			</div>
			<div class="row">
				<label for="password">Contact</label>
				<input type="text" name="contact" class="form-control" id="password" autocomplete="off" required>
			</div>
			<div class="row mt-3">
				<input type="submit" name="btn" class="btn btn-success" value="Edit" id="submit_button">
			</div>
		</div>
	</form>
	<script src="js/jquery.js"></script>
	<script src="js/.js"></script>
</body>
</html>