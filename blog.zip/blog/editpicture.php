<?php 

	error_reporting(E_ALL ^ E_NOTICE);
	include('connection.php');
	$error = [];

	if(isset($_POST['btn'])){

		$filename = $_FILES['img']['name'];
		$filetype = $_FILES['img']['type'];
		$filetemp = $_FILES['img']['tmp_name'];

		$update = mysqli_query($connection,"UPDATE profile SET img='$filename'");

		if($update){

			$location = "profilepic/".basename($filename);
			$move = move_uploaded_file($filetemp, $location);

			if($move){

				$error[] = "<p class='alert alert-success'>profile updated</p>";
				header("location:profile1.php");
			}else{

				$error[] = "<p class='alert alert-danger'>failed to update</p>";
			}
		}

	}

 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/editprofile.css">
</head>
<body>
	<form class="container col-lg-4 bg-light p-5 mt-5 rounded" enctype="multipart/form-data" method="post" action="">
		<h2 class="text-center border-bottom">Edit Profile</h2>
		<div class="m-1">
			<div class="row" id="result">
				<?php 

					foreach($error as $e){

						echo $e;
					}
				 ?>
			</div>
			<div class="row">
				<label for="picture">Profile Picture</label>
				<input type="file" name="img" class="form-control" id="picture" autocomplete="off">
			</div>
			<div class="row mt-3">
				<input type="submit" name="btn" class="btn btn-success" value="Edit" id="submit_button">
			</div>
		</div>
	</form>
</body>
</html>