
	$("#submit_button").click(function(){
		let username = $("#username").val();
		let password = $("#password").val();
		let email = $("#email").val();

		$.post("signup_data.php",{
			username:username,password:password,email:email
		},function(data){
			$("#result").html(data);
		});
	});