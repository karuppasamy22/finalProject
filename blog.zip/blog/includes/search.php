<?php 


	error_reporting(E_ALL ^ E_NOTICE);
	include("../connection.php");

	$key = $_GET['key'];
	$error = [];

	$get = "SELECT * FROM post WHERE catagory LIKE '$key%'";
	$query = mysqli_query($connection,$get);
	$num = mysqli_num_rows($query);

	if($num != 0){

		$error[] = "<p class=' container mt-5 alert alert-success'>Search found for <b>$key</b></p>";
	}else{

		$error[] = "<p class=' container mt-5 alert alert-danger'>search not found for <b>$key</b></p>";
	}



 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../css/home.css">
</head>
<body>
	<div class="container">
		<div class="row">
			<?php 

				foreach($error as $e){
					echo $e;
				}
			 ?>
		</div>
		<?php 

				error_reporting(E_ALL ^ E_NOTICE);
				include("../connection.php");


				$fetch = mysqli_query($connection,"SELECT * FROM post WHERE catagory LIKE '$key%'ORDER BY id DESC");

				while($row = mysqli_fetch_assoc($fetch)){
					$id = $row['id'];
					$title = $row['title'];
					$content = $row['content'];
					$img = $row['img'];
					$author = $row['author'];
					$tags = $row['tag'];
					$catagory = $row['catagory'];
					$date = $row['pdate'];

					echo "
						<div id='main' class='rounded p-5 mt-5'>
						<a href='../viewpost.php?id=$id'>
						<table class='table table-borderless'>
							<tr>
								<th>
									<h3>$title</h3>
								</th>
								<th>
									
								</th>
								<th></th>
								<th></th>
								<th></th>
								<th></th>
								<th></th>
								<th>
									author:$author|
									tags:$tags|$date
								</th>
							</tr>
							<tr>
								<td>
									<img src='../uploads/$img' width='100px' height='100px'>
								</td>
								<td class= colspan='6'>
									$content.<strong>catagory:$catagory</string>
								</td>
							</tr>
						</table></a>
						</div>
					";
				}

 			?>
	</div>
</body>
</html>