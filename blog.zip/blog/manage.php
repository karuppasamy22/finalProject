<?php 

	error_reporting(E_ALL ^ E_NOTICE);
	include("connection.php");

	$fetch1 = mysqli_query($connection,"SELECT * FROM signup");
	$num1 = mysqli_num_rows($fetch1);

	$fetch2 = mysqli_query($connection,"SELECT * FROM post");
	$num2 = mysqli_num_rows($fetch2);

	$fetch3 = mysqli_query($connection,"SELECT * FROM comment");
	$num3 = mysqli_num_rows($fetch3);

	$fetch4 = mysqli_query($connection,"SELECT * FROM feedback");
	$num4 = mysqli_num_rows($fetch4);

 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/manage.css">
</head>
<body>
	<div class="container rounded mt-5" id="container">
		<p><a href="profile1.php" class="text-primary">Go Back</a></p>
		<h1 class="alert alert-success">USER STATS</h1>
		<table class="table">
		  <thead>
		    <tr>
		      <th >total users</th>
		      <th >total posts</th>
		      <th >total comments</th>
		      <th >total feedback</th>
		    </tr>
		  </thead>
		  <tbody>
		    <tr>
		      <td><?php echo $num1; ?></td>
		      <td><?php echo $num2; ?></td>
		      <td><?php echo $num3; ?></td>
		      <td><?php echo $num4; ?></td>
		    </tr>
		  </tbody>
		</table>
		<h1 class="alert alert-success">USERS</h1>
		<?php 


			$f = mysqli_query($connection,"SELECT * FROM signup");

			echo "<table class='table'>";
			echo "<thead>
				    <tr>
				      <th>id</th>
				      <th>username</th>
				      <th>email</th>
				    </tr>
				  </thead>";

			while($q = mysqli_fetch_assoc($f)){

				$id = $q['id'];
				$name = $q['username'];
				$email = $q['email'];

				echo "
					  <tbody>
					    <tr>
					      <td>$id</td>
					      <td>$name</td>
					      <td>$email</td>
					      <td><a href='deleteuser.php?id=$id'>delete</a></td>
					    </tr>
					  </tbody>
					
				";
			}

			echo "</table>";

		 ?>
		 <h1 class="alert alert-success">POSTS</h1>
		<?php 


			$f = mysqli_query($connection,"SELECT * FROM post");

			echo "<table class='table'>";

			echo "<thead>
				    <tr>
				      <th>id</th>
				      <th>title</th>
				    </tr>
				  </thead>";

			while($q = mysqli_fetch_assoc($f)){

				$id = $q['id'];
				$name = $q['title'];

				echo "
					  <tbody>
					    <tr>
					      <td>$id</td>
					      <td>$name</td>
					      <td><a href='deletepost.php?id=$id'>delete</a></td>
					      <td><a href='editpost.php?id=$id'>edit</a></td>
					    </tr>
					  </tbody>
					
				";
			}

			echo "</table>";

		 ?>
		 <h1 class="alert alert-success">FEEDBACK</h1>
		<?php 


			$f = mysqli_query($connection,"SELECT * FROM feedback");

			echo "<table class='table'>";

			echo "<thead>
				    <tr>
				      <th>id</th>
				      <th>email</th>
				      <th>feedback</th>
				    </tr>
				  </thead>";

			while($q = mysqli_fetch_assoc($f)){

				$id = $q['id'];
				$e = $q['email'];
				$feed = $q['feedback'];

				echo "
					  <tbody>
					    <tr>
					      <td>$id</td>
					      <td>$e</td>
					      <td>$feed</td>
					      <td><a href='deletefeed.php?id=$id'>delete</a></td>
					    </tr>
					  </tbody>
					
				";
			}

			echo "</table>";

		 ?>
		  <h1 class="alert alert-success">COMMENTS</h1>
		 <?php 


			$f = mysqli_query($connection,"SELECT * FROM comment");

			echo "<table class='table'>";

			echo "<thead>
				    <tr>
				      <th>id</th>
				      <th>email</th>
				      <th>comment</th>
				    </tr>
				  </thead>";

			while($q = mysqli_fetch_assoc($f)){

				$id = $q['id'];
				$name = $q['username'];
				$cmt = $q['comment'];

				echo "
					  <tbody>
					    <tr>
					      <td>$id</td>
					      <td>$name</td>
					      <td>$cmt</td>
					      <td><a href='deletecmt.php?id=$id'>delete</a></td>
					    </tr>
					  </tbody>
					
				";
			}

			echo "</table>";

		 ?>
	</div>
</body>
</html>