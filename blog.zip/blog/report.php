<?php 

	session_start();

	$e = $_SESSION['email'];
	$u = $_SESSION['username'];

	error_reporting(E_ALL ^ E_NOTICE);
	include("connection.php");
	$error = [];

	if(isset($_POST['btn'])){

		$feedback = $_POST['feedback'];

		$insert = "INSERT INTO feedback(email,feedback) VALUES('$e','$feedback')";
		$query = mysqli_query($connection,$insert);

		if($query){

			$error[] = "<p class='alert alert-success'>success</p>";
		}else{
			$error[] = "<p class='alert alert-danger'>failed to sent</p>";
		}
	}



 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/report.css">
</head>
<body>
	<form class="container col-lg-4 bg-light p-5 mt-5 rounded" method="post" action="">
		<h2 class="text-center border-bottom">Feedback</h2>
		<div class="m-1">
			<div class="row" id="result">
				<?php 

					foreach($error as $e){
						echo $e;
					}

				 ?>
			</div>
			<div class="row">
				<label for="report">feedback Here</label>
				<textarea id="report" name="feedback" class="form-control" required></textarea>
			</div>
			<div class="row mt-3">
				<input type="submit" name="btn" class="btn btn-success" value="send" id="submit_button">
			</div>
			<div class="row mt-3">
				<p class="text-center"><a href="index.php" class="">Go Home</a></p>
			</div>
			
		</div>
	</form>
</body>
</html>