<?php 

	error_reporting(E_ALL ^ E_NOTICE);
	include('connection.php');

	session_start();
	$e = $_SESSION['email'];
	$u = $_SESSION['username'];

	$fet = mysqli_query($connection,"SELECT * FROM profile");
	while($fetch = mysqli_fetch_assoc($fet)){
		$bio = $fetch['bio'];
		$edu = $fetch['education'];
		$work = $fetch['work'];
		$img = $fetch['img'];
		$int = $fetch['interest'];
		$con = $fetch['contact'];
	}

 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/profile1.css">
</head>
<body>
	<div class="container rounded mt-5" id="container">
		<p><a href="index.php" class="text-primary">Go Home</a></p>
		<div class="m-5">
			<img src="profilepic/<?php echo $img; ?>" width="150px" height="150px" id="img">
			<h1 class="h1">INFINITI</h1>
			<?php 

				if($e && $u){ ?>

					<ul class="list-group list-group-horizontal mt-3">
						<li class="list-group-item"><a href="editprofile.php">Profile Edit</a></li>
						<li class="list-group-item"><a href="addpost.php">Add post</a></li>
						<li class="list-group-item"><a href="manage.php">Manage</a></li>
					</ul>
			<?php } else if(!$e && !$u) { ?>

				<p class="alert alert-primary">signin and see more...</p>

			<?php }


			 ?>
		</div>
		<div class="container">
			<div>
				<h4>Bio</h4>
				<p>
					 <?php echo $bio; ?>
				</p>
			</div>
			<div>
				<h4>Edcation</h4>
				<p>
					 <?php echo $edu; ?>
				</p>
			</div>
			<div>
				<h4>Work</h4>
				<p>
					<?php echo $work; ?>
				</p>
			</div>
			<div>
				<h4>Interest</h4>
				<p>
					 <?php echo $int; ?>
				</p>
			</div>
			<div>
				<h4>contact</h4>
				<p>
					 <?php echo $con; ?>
				</p>
			</div>
		</div>
	</div>
</body>
</html>