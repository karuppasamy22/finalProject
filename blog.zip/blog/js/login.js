$("#submit_button").click(function(){
	let email = $("#email").val();
	let password = $("#password").val();

	$.post("../includes/login.php",{

		email:email,password:password
	},
	function(data){
		$("#result").html(data);
	});
});