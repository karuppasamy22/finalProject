<?php 

	error_reporting(E_ALL ^ E_NOTICE);
	include('connection.php');
	$error = [];
	$pid = $_GET['id']; 

	session_start();
	$e = $_SESSION['email'];
	$u = $_SESSION['username'];

	if(isset($_POST['cmtbtn'])){

		if(!$e&& !$u){

			$error[] = "<p class='alert alert-danger'>Please signin</p>";
		}else{

			$cmt = $_POST['cmt'];

			$insert = mysqli_query($connection,"INSERT INTO comment(pid,username,comment) VALUES('$pid','$u','$cmt')");

			if($insert){

				$error[] = "<p class='alert alert-success'>commented</p>";
			}else{

				$error[] = "<p class='alert alert-danger'>failed to comment</p>";
			}
		}
	}


 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/home.css">
	<script type="text/javascript" src="js/jquery.js"></script>
	
</head>
<body>
	<div class="container">

			<?php 

				error_reporting(E_ALL ^ E_NOTICE);
				include("connection.php");

				$get = $_GET['id'];
				$fetch = mysqli_query($connection,"SELECT * FROM post WHERE id='$get'");

				while($row = mysqli_fetch_assoc($fetch)){
					$id = $row['id'];
					$title = $row['title'];
					$content = $row['content'];
					$img = $row['img'];
					$author = $row['author'];
					$tags = $row['tag'];
					$catagory = $row['catagory'];
					$date = $row['pdate'];

					echo "
						<div id='main' class='rounded p-5 mt-5'>
						<a href='index.php' class='text-primary'>Go Home</a>
						<a href='viewpost.php?id=$id'>
						<table class='table table-borderless'>
							<tr>
								<th>
									<h3>$title</h3>
								</th>
								<th>
									
								</th>
								<th></th>
								<th></th>
								<th></th>
								<th></th>
								<th></th>
								<th>
									author:<em class='font-weight-lighter'>$author</em>|
									tags:<em class='font-weight-lighter'>$tags</em>|$date
								</th>
							</tr>
							<tr>
								<td>
									<img src='uploads/$img' width='100px' height='100px'>
								</td>
								<td class= colspan='6'>
									$content.<strong>catagory:$catagory</string>
								</td>
							</tr>
						</table></a>
						<p>share!<img src='images/share_96px.png' width='16px' height='16px' id='img1'/></p>
						</div>
					";
				}

 			?>
 			<form class="form m-3" method="post" action="">
 				<div>
 					<?php 

 						foreach($error as $e){

 							echo $e;
 						}

 						$ct = mysqli_query($connection,"SELECT * FROM comment WHERE pid='$get' ORDER BY id DESC");
						$num = mysqli_num_rows($ct);

 					 ?>
 				</div>
 				<p class="form-control-text alert alert-success">comment here... <strong> total comments <?php echo " $num"; ?></strong></p>
 				<textarea class="form-control" name="cmt" required></textarea>
 				<input type="submit" name="cmtbtn" value="comment" class="btn btn-primary mt-3">
 			</form>
		
	</div>
		<?php 

			$ft = mysqli_query($connection,"SELECT * FROM comment WHERE pid='$get' ORDER BY id DESC");

			while($row = mysqli_fetch_assoc($ft)){

				$u = $row['username'];
				$c = $row['comment'];

				echo "<div id='main' class='container mt-3 p-5'>";
					echo "

						<table class=''>
							<tr > 
								<td><strong>$u</strong></td>
							</tr>
							<tr>
								<td class='pl-5 pt-3'>$c</td>
							</tr>
						</table>

					";
				echo "</div>";

			}


		 ?>
	
	<div id="menu1" class="rounded">
		<p><a href="" class="text-muted">copy link</a></p>
		<p><a href="" class="text-muted">facebook</a></p>
		<p><a href="" class="text-muted">twitter</a></p>
		<p><a href="" class="text-muted">gmail</a></p>
	</div>
	<script type="text/javascript">
		$(document).ready(function(){
			$("#img1").click(function(){
				$("#menu1").toggle("fast");
			});
		});
	</script>
</body>
</html>