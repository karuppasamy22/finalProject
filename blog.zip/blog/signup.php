<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/signup.css">
</head>
<body>
	<div class="container col-lg-4 bg-light p-5 mt-5 rounded">
		<h2 class="text-center border-bottom">Signup to continue!</h2>
		<div class="m-1">
			<div class="row" id="result">
				
			</div>
			<div class="row">
				<label for="username">Username</label>
				<input type="text" name="" class="form-control" id="username" autocomplete="off" required>
			</div>
			<div class="row">
				<label for="email">Email address</label>
				<input type="email" name="" class="form-control" id="email" autocomplete="off" required>
			</div>
			<div class="row">
				<label for="password">Password</label>
				<input type="password" name="" class="form-control" id="password" autocomplete="off" required>
			</div>
			<div class="row mt-3">
				<input type="submit" name="" class="btn btn-success" value="signup" id="submit_button">
			</div>
			<div class="row mt-3">
				<p class="text-center">Already have an account?</p><a href="signin.php" class="">Signin</a>
			</div>
			
		</div>
	</div>
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript">
		$(document).ready(function(){
			$("#submit_button").click(function(){
				let username = $("#username").val();
				let password = $("#password").val();
				let email = $("#email").val();

				$.post("includes/insert.php",{
					username:username,password:password,email:email
				},function(data){
					$("#result").html(data);
				});
			});
		});
	</script>
</body>
</html>